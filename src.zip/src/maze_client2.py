from MazeClient import test4

test4()