from MazeClient import test5


test5()
