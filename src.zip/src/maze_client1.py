from MazeClient import test3

test3()